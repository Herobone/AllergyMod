package mekanism.common.frequency;

public interface IFrequencyHandler 
{
	public Frequency getFrequency(FrequencyManager manager);
}
