package mekanism.common.base;

public interface IMetaItem 
{
	public String getTexture(int meta);
	
	public int getVariants();
}
