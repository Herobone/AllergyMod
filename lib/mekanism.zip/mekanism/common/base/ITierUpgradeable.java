package mekanism.common.base;

import mekanism.common.Tier.BaseTier;

public interface ITierUpgradeable 
{
	public boolean upgrade(BaseTier upgradeTier);
}
