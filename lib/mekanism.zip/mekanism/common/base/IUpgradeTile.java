package mekanism.common.base;

import mekanism.common.tile.component.TileComponentUpgrade;

public interface IUpgradeTile
{
	public TileComponentUpgrade getComponent();
}
