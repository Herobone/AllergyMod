package mekanism.common.base;

public interface IChunkLoadHandler 
{
	public void onChunkLoad();
}
