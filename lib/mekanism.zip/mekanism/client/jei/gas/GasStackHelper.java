package mekanism.client.jei.gas;


public class GasStackHelper// implements IIngredientHelper<GasStack>
{
	/*@Override
	public Collection<GasStack> expandSubtypes(Collection<GasStack> contained) {
		return contained;
	}

	@Override
	public GasStack getMatch(Iterable<GasStack> ingredients, @Nonnull Focus toMatch) {
		if (toMatch.getGas() == null) {
			return null;
		}
		for (GasStack GasStack : ingredients) {
			if (toMatch.getGas() == GasStack.getGas()) {
				return GasStack;
			}
		}
		return null;
	}

	@Nonnull
	@Override
	public Focus createFocus(@Nonnull GasStack ingredient) {
		return new Focus(ingredient.getGas());
	}*/
}
