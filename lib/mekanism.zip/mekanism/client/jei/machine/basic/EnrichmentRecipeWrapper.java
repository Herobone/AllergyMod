package mekanism.client.jei.machine.basic;

import mekanism.client.jei.machine.MachineRecipeCategory;
import mekanism.client.jei.machine.MachineRecipeWrapper;
import mekanism.common.recipe.machines.BasicMachineRecipe;

public class EnrichmentRecipeWrapper extends MachineRecipeWrapper
{
	public EnrichmentRecipeWrapper(BasicMachineRecipe r, MachineRecipeCategory c)
	{
		super(r, c);
	}
}
