package mekanism.client.jei.machine.chance;

import mekanism.client.jei.machine.ChanceMachineRecipeCategory;
import mekanism.client.jei.machine.ChanceMachineRecipeWrapper;
import mekanism.common.recipe.machines.ChanceMachineRecipe;

public class PrecisionSawmillRecipeWrapper extends ChanceMachineRecipeWrapper
{
	public PrecisionSawmillRecipeWrapper(ChanceMachineRecipe r, ChanceMachineRecipeCategory c)
	{
		super(r, c);
	}
}
